package com.example.webapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.webapp.entity.ApplicationForm;
import com.example.webapp.service.Appformservices;


@Controller
//@RequestMapping("/webapp")
public class WebAppController {
	
	@Autowired
	Appformservices appservice;
	
	@GetMapping("/")
	public String applicationForm(){
		return "index";
	}
	@PostMapping("/onsubmit")
	public String getFormDetails(@ModelAttribute ApplicationForm appform) {
		System.out.println(appservice.saveData(appform));
		System.out.println(appform.toString());
		return "welcome";
	}
}
