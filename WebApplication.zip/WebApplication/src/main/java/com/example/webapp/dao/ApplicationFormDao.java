package com.example.webapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.webapp.entity.ApplicationForm;

public interface ApplicationFormDao extends JpaRepository<ApplicationForm, Integer> {

}
