package com.example.webapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.webapp.dao.ApplicationFormDao;
import com.example.webapp.entity.ApplicationForm;

@Service
public class Appformservices {
	
	@Autowired
	ApplicationFormDao appformdao;
	
	public String saveData(ApplicationForm appform) {
		appformdao.save(appform);
		return "success";
	}
}
